### Installing SQL

Please write a readme to install sql databases and the like.

-	In this folder you should export your whole DB instance you had in testing.
-	Also should have command on how to run the .sql scripts so the user can setup the DB
